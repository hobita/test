from flask import Flask, request, jsonify
from slack_sdk import WebClient
import paramiko

app = Flask(__name__)

# === SSH Helpers ===

def ssh_connect(host, user, password, command):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname=host, username=user, password=password)

        stdin, stdout, stderr = client.exec_command(command)
        stdout.channel.recv_exit_status()  # Wait for command to finish

        output = stdout.read().decode('utf-8', errors='ignore').strip()
        error = stderr.read().decode('utf-8', errors='ignore').strip()

        client.close()
        return output, error

    except Exception as e:
        return "", str(e)

def ssh_run_script_from_url(host, user, password, script_url):
    script_url = script_url.strip('<>')  # Remove angle brackets if pasted from Slack
    script_name = script_url.split("/")[-1]

    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname=host, username=user, password=password)

        command = (
            f"curl -s -O {script_url} && "
            f"chmod +x {script_name} && "
            f"./{script_name} 2>&1"
        )

        stdin, stdout, stderr = client.exec_command(command)
        stdout.channel.recv_exit_status()

        output = stdout.read().decode('utf-8', errors='ignore').strip()
        client.close()

        if not output:
            output = "(✅ Script ran but returned no output.)"

        return output, ""

    except Exception as e:
        return "", f"❌ SSH Error: {e}"


# === Slack Setup ===

slack_token = "xoxb-9286285858423-9317413199649-anlZkc6UpgIh4NDjL8QUyMJb"
client = WebClient(token=slack_token)

def send_message(channel, text):
    try:
        response = client.chat_postMessage(channel=channel, text=text)
        return response
    except Exception as e:
        print(f"📤 Slack send_message failed: {e}")
        return None


# === REST API Routes ===

@app.route('/ssh', methods=['POST'])
def run_command():
    try:
        data = request.get_json()
        host = data['host']
        user = data['user']
        password = data['password']
        command = data['command']

        output, error = ssh_connect(host, user, password, command)

        return jsonify({
            "success": error == "",
            "output": output,
            "error": error
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@app.route('/run-script', methods=['POST'])
def run_script():
    try:
        data = request.get_json()
        host = data['host']
        user = data['user']
        password = data['password']
        script_url = data['script_url']

        output, error = ssh_run_script_from_url(host, user, password, script_url)

        return jsonify({
            "success": error == "",
            "output": output,
            "error": error
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400


# === Slack Bot Event Endpoint ===

@app.route('/slack/events', methods=['POST'])
def slack_events():
    data = request.json

    # Verification challenge
    if 'challenge' in data:
        return jsonify({'challenge': data['challenge']})

    # Process event
    if 'event' in data:
        event = data['event']
        text = event.get('text', '').strip()
        channel = event['channel']

        if text.lower().startswith("!ssh"):
            try:
                parts = text.split()
                _, host, user, password, *cmd_parts = parts
                command = " ".join(cmd_parts)

                output, error = ssh_connect(host, user, password, command)

                if error:
                    send_message(channel, f":x: Error:\n```{error}```")
                else:
                    send_message(channel, f":white_check_mark: Output:\n```{output}```")

            except Exception as e:
                send_message(channel, f"❌ Failed to run command: {e}")

        elif text.lower().startswith("!runscript"):
            try:
                parts = text.split()
                if len(parts) < 5:
                    send_message(channel, "⚠️ Usage: `!runscript <host> <user> <password> <script_url>`")
                else:
                    _, host, user, password, script_url = parts[:5]

                    output, error = ssh_run_script_from_url(host, user, password, script_url)

                    if error:
                        send_message(channel, f":x: Error:\n```{error}```")
                    else:
                        send_message(channel, f":white_check_mark: Output:\n```{output}```")

            except Exception as e:
                send_message(channel, f"❌ Failed to run script: {e}")

    return '', 200


# === Launch Flask Server ===

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

