import platform

print("👋 Hello, Rayen!")
print("🔍 System info:")
print(f"System: {platform.system()}")
print(f"Release: {platform.release()}")
print(f"Machine: {platform.machine()}")
