from flask import Flask, request, jsonify
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
import paramiko
import json
import requests
from tempfile import NamedTemporaryFile

app = Flask(__name__)

# === Slack Setup ===
slack_token = "xoxb-9286285858423-9317413199649-HTwjNF8CCX7E5NzjEmPPv6OB"
client = WebClient(token=slack_token)

# === SSH Helpers ===

def ssh_connect(host, user, password, command):
    try:
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(hostname=host, username=user, password=password)

        stdin, stdout, stderr = ssh_client.exec_command(command)
        stdout.channel.recv_exit_status()

        output = stdout.read().decode('utf-8', errors='ignore').strip()
        error = stderr.read().decode('utf-8', errors='ignore').strip()

        ssh_client.close()
        return output, error
    except Exception as e:
        return "", str(e)

def ssh_run_script_from_url(host, user, password, script_url):
    script_url = script_url.strip('<>')  # Remove angle brackets if any
    script_name = script_url.split("/")[-1]

    try:
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(hostname=host, username=user, password=password)

        command = f"curl -s -O {script_url} && chmod +x {script_name} && ./{script_name} 2>&1"

        stdin, stdout, stderr = ssh_client.exec_command(command)
        stdout.channel.recv_exit_status()

        output = stdout.read().decode('utf-8', errors='ignore').strip()
        ssh_client.close()

        if not output:
            output = "(✅ Script ran but returned no output.)"

        return output, ""
    except Exception as e:
        return "", f"❌ SSH Error: {e}"

def ssh_get_log(host, user, password, remote_path, local_path):
    try:
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(hostname=host, username=user, password=password)

        sftp = ssh_client.open_sftp()
        sftp.get(remote_path, local_path)
        sftp.close()
        ssh_client.close()

        return True, ""
    except Exception as e:
        return False, str(e)

# === Slack Interaction Handlers ===

def send_main_menu(channel):
    blocks = [
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": "Please choose an action:"}
        },
        {
            "type": "actions",
            "elements": [
                {"type": "button", "text": {"type": "plain_text", "text": "Run Script"}, "value": "run_script", "action_id": "run_script"},
                {"type": "button", "text": {"type": "plain_text", "text": "Run Command"}, "value": "run_command", "action_id": "run_command"},
                {"type": "button", "text": {"type": "plain_text", "text": "Get Log File"}, "value": "get_log", "action_id": "get_log"},
                {"type": "button", "text": {"type": "plain_text", "text": "Download Nexus File"}, "value": "nexus_file", "action_id": "nexus_file"}  # NEW BUTTON
            ]
        }
    ]
    client.chat_postMessage(channel=channel, text="Choose an action:", blocks=blocks)

def open_modal(trigger_id, view):
    try:
        client.views_open(trigger_id=trigger_id, view=view)
    except SlackApiError as e:
        print(f"Error opening modal: {e.response['error']}")

@app.route('/slack/interactions', methods=['POST'])
def slack_interactions():
    payload = request.form.get('payload')
    if not payload:
        return '', 400

    data = json.loads(payload)
    # Handle block_actions (button clicks) and view_submission (modal submits)
    if data.get("type") == "block_actions":
        action = data['actions'][0]
        action_id = action.get('action_id')
        trigger_id = data.get('trigger_id')
        channel_id = data['channel']['id']

        if action_id == "run_script":
            modal_view = {
                "type": "modal",
                "callback_id": "run_script_view",
                "title": {"type": "plain_text", "text": "Run Script"},
                "submit": {"type": "plain_text", "text": "Run"},
                "close": {"type": "plain_text", "text": "Cancel"},
                "private_metadata": channel_id,   # Pass channel ID here
                "blocks": [
                    {
                        "type": "input",
                        "block_id": "host_block",
                        "element": {"type": "plain_text_input", "action_id": "host"},
                        "label": {"type": "plain_text", "text": "Host"}
                    },
                    {
                        "type": "input",
                        "block_id": "user_block",
                        "element": {"type": "plain_text_input", "action_id": "user"},
                        "label": {"type": "plain_text", "text": "User"}
                    },
                    {
                        "type": "input",
                        "block_id": "password_block",
                        "element": {"type": "plain_text_input", "action_id": "password", "placeholder": {"type": "plain_text", "text": "Password"}},
                        "label": {"type": "plain_text", "text": "Password"}
                    },
                    {
                        "type": "input",
                        "block_id": "script_url_block",
                        "element": {"type": "plain_text_input", "action_id": "script_url"},
                        "label": {"type": "plain_text", "text": "Script URL"}
                    }
                ]
            }
            open_modal(trigger_id, modal_view)

        elif action_id == "run_command":
            modal_view = {
                "type": "modal",
                "callback_id": "run_command_view",
                "title": {"type": "plain_text", "text": "Run Command"},
                "submit": {"type": "plain_text", "text": "Run"},
                "close": {"type": "plain_text", "text": "Cancel"},
                "private_metadata": channel_id,   # Pass channel ID here
                "blocks": [
                    {
                        "type": "input",
                        "block_id": "host_block",
                        "element": {"type": "plain_text_input", "action_id": "host"},
                        "label": {"type": "plain_text", "text": "Host"}
                    },
                    {
                        "type": "input",
                        "block_id": "user_block",
                        "element": {"type": "plain_text_input", "action_id": "user"},
                        "label": {"type": "plain_text", "text": "User"}
                    },
                    {
                        "type": "input",
                        "block_id": "password_block",
                        "element": {"type": "plain_text_input", "action_id": "password"},
                        "label": {"type": "plain_text", "text": "Password"}
                    },
                    {
                        "type": "input",
                        "block_id": "command_block",
                        "element": {"type": "plain_text_input", "action_id": "command", "multiline": True},
                        "label": {"type": "plain_text", "text": "Command"}
                    }
                ]
            }
            open_modal(trigger_id, modal_view)

        elif action_id == "get_log":
            modal_view = {
                "type": "modal",
                "callback_id": "get_log_view",
                "title": {"type": "plain_text", "text": "Get Log File"},
                "submit": {"type": "plain_text", "text": "Get"},
                "close": {"type": "plain_text", "text": "Cancel"},
                "private_metadata": channel_id,   # Pass channel ID here
                "blocks": [
                    {
                        "type": "input",
                        "block_id": "host_block",
                        "element": {"type": "plain_text_input", "action_id": "host"},
                        "label": {"type": "plain_text", "text": "Host"}
                    },
                    {
                        "type": "input",
                        "block_id": "user_block",
                        "element": {"type": "plain_text_input", "action_id": "user"},
                        "label": {"type": "plain_text", "text": "User"}
                    },
                    {
                        "type": "input",
                        "block_id": "password_block",
                        "element": {"type": "plain_text_input", "action_id": "password"},
                        "label": {"type": "plain_text", "text": "Password"}
                    },
                    {
                        "type": "input",
                        "block_id": "log_path_block",
                        "element": {"type": "plain_text_input", "action_id": "log_path"},
                        "label": {"type": "plain_text", "text": "Remote Log Path"}
                    }
                ]
            }
            open_modal(trigger_id, modal_view)

        elif action_id == "nexus_file":  # NEW HANDLER FOR NEXUS FILE
            modal_view = {
                "type": "modal",
                "callback_id": "nexus_file_view",
                "title": {"type": "plain_text", "text": "Download Nexus File"},
                "submit": {"type": "plain_text", "text": "Download"},
                "close": {"type": "plain_text", "text": "Cancel"},
                "private_metadata": channel_id,
                "blocks": [
                    {
                        "type": "input",
                        "block_id": "nexus_url_block",
                        "element": {"type": "plain_text_input", "action_id": "nexus_url"},
                        "label": {"type": "plain_text", "text": "Nexus File URL"}
                    },
                    {
                        "type": "input",
                        "block_id": "nexus_user_block",
                        "optional": True,
                        "element": {"type": "plain_text_input", "action_id": "nexus_user"},
                        "label": {"type": "plain_text", "text": "Username (optional)"}
                    },
                    {
                        "type": "input",
                        "block_id": "nexus_password_block",
                        "optional": True,
                        "element": {"type": "plain_text_input", "action_id": "nexus_password"},
                        "label": {"type": "plain_text", "text": "Password (optional)"}
                    }
                ]
            }
            open_modal(trigger_id, modal_view)

        elif action_id == "return_to_menu":
            send_main_menu(channel_id)

        return '', 200

    elif data.get("type") == "view_submission":
        view = data['view']
        callback_id = view['callback_id']
        channel_id = view.get('private_metadata')  # Get original channel from private_metadata

        state_values = view['state']['values']

        try:
            if callback_id == "run_script_view":
                host = state_values['host_block']['host']['value']
                user = state_values['user_block']['user']['value']
                password = state_values['password_block']['password']['value']
                script_url = state_values['script_url_block']['script_url']['value']

                output, error = ssh_run_script_from_url(host, user, password, script_url)

                message = f":white_check_mark: Script Output:\n```{output}```" if not error else f":x: Error:\n```{error}```"
                client.chat_postMessage(channel=channel_id, text=message)
                send_main_menu(channel_id)

            elif callback_id == "run_command_view":
                host = state_values['host_block']['host']['value']
                user = state_values['user_block']['user']['value']
                password = state_values['password_block']['password']['value']
                command = state_values['command_block']['command']['value']

                output, error = ssh_connect(host, user, password, command)

                message = f":white_check_mark: Command Output:\n```{output}```" if not error else f":x: Error:\n```{error}```"
                client.chat_postMessage(channel=channel_id, text=message)
                send_main_menu(channel_id)

            elif callback_id == "get_log_view":
                host = state_values['host_block']['host']['value']
                user = state_values['user_block']['user']['value']
                password = state_values['password_block']['password']['value']
                remote_path = state_values['log_path_block']['log_path']['value']

                local_path = f"/tmp/{remote_path.split('/')[-1]}"

                success, error = ssh_get_log(host, user, password, remote_path, local_path)

                if success:
                    try:
                        client.files_upload_v2(
                            channel=channel_id,
                            file=local_path,
                            title=f"Log file: {remote_path}",
                            initial_comment=f"✅ Log file `{remote_path}` retrieved successfully."
                        )
                    except SlackApiError as e:
                        client.chat_postMessage(channel=channel_id, text=f"❌ Slack upload failed: {e.response['error']}")
                else:
                    client.chat_postMessage(channel=channel_id, text=f"❌ Error fetching log: {error}")

                send_main_menu(channel_id)

            elif callback_id == "nexus_file_view":  # NEW: Handle Nexus file modal submission
                nexus_url = state_values['nexus_url_block']['nexus_url']['value']
                nexus_user = state_values.get('nexus_user_block', {}).get('nexus_user', {}).get('value')
                nexus_password = state_values.get('nexus_password_block', {}).get('nexus_password', {}).get('value')

                try:
                    auth = None
                    if nexus_user and nexus_password:
                        auth = (nexus_user, nexus_password)

                    # Download the file from Nexus
                    response = requests.get(nexus_url, auth=auth)
                    response.raise_for_status()

                    # Save to temp file
                    with NamedTemporaryFile(delete=False) as tmp_file:
                        tmp_file.write(response.content)
                        tmp_filepath = tmp_file.name

                    # Upload file to Slack
                    client.files_upload_v2(
                        channel=channel_id,
                        file=tmp_filepath,
                        title=f"Nexus File: {nexus_url.split('/')[-1]}",
                        initial_comment=f"✅ Successfully retrieved file from Nexus."
                    )
                except Exception as e:
                    client.chat_postMessage(channel=channel_id, text=f"❌ Failed to download/upload Nexus file: {str(e)}")

                send_main_menu(channel_id)

            return '', 200

        except Exception as e:
            # Respond with errors gracefully
            client.chat_postMessage(channel=channel_id, text=f"❌ Error processing your request: {e}")
            send_main_menu(channel_id)
            return '', 200

    return '', 200

# === Slack Events Endpoint ===

@app.route('/slack/events', methods=['POST'])
def slack_events():
    data = request.json
    # Slack URL verification challenge
    if 'challenge' in data:
        return jsonify({'challenge': data['challenge']})

    if 'event' in data:
        event = data['event']
        text = event.get('text', '').strip().lower()
        channel = event['channel']

        # Show main menu on 'menu' or 'start'
        if text in ('menu', 'start'):
            send_main_menu(channel)
            return '', 200

    return '', 200

# === Run Flask Server ===

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

